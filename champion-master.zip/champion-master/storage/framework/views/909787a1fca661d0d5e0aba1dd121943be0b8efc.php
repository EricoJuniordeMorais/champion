<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
        <link href="/css/app.css" rel="stylesheet">
        <title>CHAMPION DEALER</title>

        <style>
            h1{
              color: #000000;
            }
            nav{
              background-color: #ffffff;
            }
            small{
              color: #e02b20 ! important;
            }
            body {
              font-family: 'Arial';
              background-color: #ffffff;
            }
            h3{
              color: #e02b20 ! important;
            }
            a:hover{
              text-decoration: none;
            }
            footer{
              background-color: #e02b20;
              font-weight: bold;
              color: #ffffff;
            }
            .product-link{
              color: #000000;
            }
            .product-link:hover{
              color: #000000;
            }
            .banner{
              height: 100%;
              width: 100%;
              position: absolute;
              top: 0;
              left: 0;
              z-index: 0;
            }
            .proportion{
              padding-top:48.25%;
              width: 100%;
              position: relative;
            }
            /* .logo{
              height: 78px;
            } */
            .shop{
              font-weight: bold;
              font-size: 150%;
              color: #e02b20 ! important;
            }
            .shop:hover{
              color: #e02b20 ! important;
              filter: brightness(75%) ! important;
            }
            .contact-info{
              display:flex;
              margin-left:auto;
              margin-right:auto;
            }
            .info{
              width: 33.33%;
            }
            .info-content{
              margin: -15px 0 20px 0;
            }
            .logo{
                display: flex;
            }
            .logo-image{
                max-height: 78px;
            }
            .logo-name{
                margin-top: auto;
                margin-bottom: auto;
            }
            .responsive-info-nav{
              display: flex;
            }
            .responsive-item-nav{
              width: 50%;
              margin: 15px;
            }

            .add-phone{
              color: #e02b20;
              width: fit-content;
            }
            .add-phone-text{
              font-size: x-large;
            }
            .add-phone-icon{
              font-size: xx-large;
            }
            .add-phone:hover{
              cursor: pointer;
            }
            .add-phone-text:hover{
              cursor: pointer;
            }
            .navbar-link{
              font-weight: bold;
              font-size: 150%;
              color: #e02b20 ! important;
            }
            .remove-phone{
              color: #e02b20;
            }
            .remove-phone-text{
              font-size: x-large;
            }
            .remove-phone-icon{
              font-size: xx-large;
            }
            .remove-phone:hover{
              cursor: pointer;
            }
            .remove-phone-text:hover{
              cursor: pointer;
            }
            .sub-title{
              color: #e02b20;
              font-weight: bold;
              margin: 15px;
            }
            @media (max-width: 600px){
              .responsive-info{
                display: flex;
                margin-bottom: 15px
              }
              .responsive-info-nav{
                display: flex;
              }
              .responsive-item{
                width: 50%;
              }
              .responsive-item-email{
                width: 50%;
                border-right: solid;
                border-width: 1px;
                border-color: #ffffff;
              }
              .contact-info{
                  flex-direction: column;
              }
              .info{
                  width: 100%;
                  margin-right: 5px;
              }
              .logo{
                flex-direction: column;
                margin-left: auto;
                margin-right: auto;
                width: 100%;
              }
              .logo-image-div{
                margin-left: auto;
                margin-right: auto;
              }
              .logo-name{
                margin-left: auto;
                margin-right: auto;
              }
            }

        </style>
    </head>
    <body class="">


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Login')); ?></div>

                <div class="card-body">
                    <form method="POST" action="/auth">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                               <!-- <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div> -->
                            </div>
                        </div>

                        <div class="form-group mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary btn-danger">
                                    <?php echo e(__('Login')); ?>

                                </button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
  <script src="/js/app.js"></script>
    </body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/champion-master/resources/views/auth/login.blade.php ENDPATH**/ ?>